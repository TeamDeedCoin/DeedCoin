/**
 * Created by Yasir to create wallet for every users
 */

// Load required packages
var mongoose = require('mongoose');

// Define our beer schema
var WalletUserSchema = new mongoose.Schema({
    Email: {type : String, unique : true},
    Password: {type :String, select: false},
    EthAddress:String,
    Tokens: Number,
    Ethers:String,
    CreatedOnUTC: Number,
    UpdatedOnUTC: Number
});

// Export the Mongoose model
module.exports = mongoose.model('WalletUser', WalletUserSchema);