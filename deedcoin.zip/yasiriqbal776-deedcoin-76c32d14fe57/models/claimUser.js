// Load required packages
var mongoose = require('mongoose');

// Define our beer schema
var claimUserschema = new mongoose.Schema({
    email:String,
    ethAddress:String,
    btcAddress: String,
    ltcAddresss:String,
    transactionhash:{type:String,unique:true},
    confirmation:Number
});

// Export the Mongoose model
module.exports = mongoose.model('claimUser', claimUserschema);