var ResponseCodeEnum = {
    DECLINED: 400,
    ERRORED: 500,
    SUCCESS: 200
};

module.exports = ResponseCodeEnum;