var CryptoCodeEnum = {
    BITCOIN: '1',
    ETHEREUM: '2',
    LITECOIN: '3'
};

module.exports = CryptoCodeEnum;