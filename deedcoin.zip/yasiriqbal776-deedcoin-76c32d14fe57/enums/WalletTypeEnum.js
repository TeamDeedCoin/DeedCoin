var WalletTypeEnum = {
    BITCOIN:1,
    ETHEREUM:2,
    LTC:3
};

module.exports = WalletTypeEnum;