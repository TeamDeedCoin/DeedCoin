var express = require('express');
var router = express.Router();
var Client = require('node-rest-client').Client;

var client = new Client();
//Models Imported
var User = require('./../models/User');
var claimUser = require('./../models/claimUser');
var WalletUser = require('./../models/WalletUser');
var passGenerator = require('generate-password');
//
var Web3 = require('web3');
var web3 = new Web3();
web3.setProvider(new web3.providers.HttpProvider('http://52.171.141.59:8545'));


//Utiltiy Imported
var PasswordHashing = require('./../utility/PasswordHashing');
var passwordHashing = new PasswordHashing();
//
//Utiltiy Imported
var tokenUtil = require('./../utility/tokenUtil');
var tokenUtil = new tokenUtil();
//
//Enums, DTO's Imported
var ResponseCodeEnum = require('./../enums/ResponseCodeEnum');
var WalletTypeEnum = require('./../enums/WalletTypeEnum');
var Response = require('./../dto/Response');
//
//Routes Defined

var postPrivateSale = router.route('/privateSale');
var postAddUser = router.route('/addUser');
var postaddclaimUser = router.route('/addclaimUser');
var postAddUserWalletInfo = router.route('/postAddUserWalletInfo');
var postLoginUser = router.route('/loginUser');
var getDashboardData = router.route('/getDashboardData');
var postWalletUser = router.route('/walletEthUser');
//Configuration Defined
var confFile = require('./../config');
var currentRate = router.route('/getcurrentRate');
var getraisedTokens = router.route('/gettokensRaised');
var getUserTokens = router.route('/getUserTokens');
//Mongo Connectivity
var mongoose = require('mongoose');
var DbUrl = require('./../utility/DbUrl');
var dbUrl = new DbUrl();
var url = dbUrl.getURL();

mongoose.connect(url, function (err, db) {
  if (err) {
    console.log(err);
  }
  else {
    console.log("App Successfully Connected");
  }
});


postPrivateSale.post(function (req, res) {
  var response = new Response();
  var userEthAddr = req.body.ethAddress;
  var userUSDBalance = req.body.userUSDBalance;
  var isAddress = web3.isAddress(userEthAddr);
  if (isAddress) {
    if (userEthAddr && userUSDBalance && userEthAddr.length > 0 && userUSDBalance > 0) {
      var transHash = tokenUtil.transferTokensForPrivateSale(userEthAddr,userUSDBalance);
        var obj = new Object();
        obj.transUrl = "https://rinkeby.etherscan.io/tx/"+ transHash;
        response.code = 200;
        response.message = "Success";
        response.data = obj;
        res.json(response);
    } else {
        response.code = 400;
        response.message = "Parameters cannot be null";
        res.json(response);
    }
  }
  else {
    response.code = 400;
    response.message = "Address is not Valid";
    res.json(response);
  }
});


currentRate.post(function (req, res) {
  var response = new Response();
  var currentvalue = 0;
  var currencyType = req.body.currency;
  client.get("https://min-api.cryptocompare.com/data/price?fsym=" + currencyType + "&tsyms=USD", function (data, responsee) {
    currentvalue = data.USD;
    response.code = 200;
    response.data = currentvalue;
    res.json(response);
  });
});
function geterasedTokens(currency, walletaddress, callback) {
  var balance = -1;
  client.get("https://api.blockcypher.com/v1/" + currency + "/main/addrs/" + walletaddress + "/balance", function (data, responsee) {
    balance = data.final_balance;
    callback(balance);
  });
  return balance;
}
getUserTokens.post(function (req, res) {
  var response = new Response();
  var addressForTokens = req.body.address;
  var ethAddr = req.body.ethAddress;
  var isForAdmin = req.body.admin;
  if(isForAdmin == 1){
    ethAddr = confFile.AdminEthAddress;
  }
  var obj = new Object();
  obj.tokens = tokenUtil.balanceOf(ethAddr);
  response.code = 200;
  response.data = obj;
  response.message = "Success";
  res.json(response);
});
getraisedTokens.post(function (req, res) {
  var response = new Response();
  var currencyType = req.body.currencyType;
  var walletAddress = "";
  if (currencyType == "BTC") {
    walletAddress = confFile.AdminBitcoinAddress;
    geterasedTokens(currencyType, walletAddress, function (balance) {
      if (balance >= 0) {
        response.code = 200;
        response.data = balance;
        res.json(response);
      }
    });
  }
  else if (currencyType = "LTC") {
    walletAddress = confFile.AdminLitcoinAddress;
    geterasedTokens(currencyType, walletAddress, function (balance) {
      if (balance >= 0) {
        response.code = 200;
        response.data = balance;
        res.json(response);
      }
    });
  }
  else {
    response.code = 201;
    res.json(response);
  }
});

/**
 * Here this route is use to get wallet address if exist other wise just return the user with wallet address along with balance.
 */
postWalletUser.get(function (req, res) {
  var response = new Response();
  var emailAddress = req.query.email; //email in body to check return users
  if (emailAddress == undefined) {
    response.code = ResponseCodeEnum.ERRORED;
    response.message = "Email canot be null";
    response.data = null;
    res.json(response);
    return;
  }
  WalletUser.findOne({ Email: emailAddress }, function (err, existingUser) {
    if (existingUser == null) {
      //user not found so register new user and return
      var password = passGenerator.generate({
        length: 22,
        numbers: true,
        symbols: true
      });//end of password generator
      var newAccount = web3.personal.newAccount(password);
      var walletUser = new WalletUser();
      walletUser.Email = emailAddress;
      walletUser.Password = password;
      walletUser.EthAddress = newAccount;
      walletUser.Ethers = "0";
      walletUser.Tokens = 0;
      walletUser.save();
      response.code = ResponseCodeEnum.SUCCESS
      response.message = "User Register Successfully";
      response.data = walletUser;
      res.json(response);

    } else {
      //here return user obj
      response.code = ResponseCodeEnum.SUCCESS
      response.message = "User Returns Successfully";
      existingUser.Ethers = web3.eth.getBalance(existingUser.EthAddress);
      response.data = existingUser;
      res.json(response);
    }//end of else for user not found
  });//end of find one querry
});//end of function postWalletUser

// Here is the code for entering Claim User
postaddclaimUser.post(function (req, res) {
  var response = new Response();
  var claim = new claimUser();
  claimUser.findOne({ Email: req.body.email }, function (err, existingUser) {
    if (existingUser != null) {
      response.code = ResponseCodeEnum.DECLINED;
      response.message = "User Already Exists";
      response.data = null;
      res.json(response);
    }
    else {
      var walletType = req.body.WalletType;
      if (walletType == 'BTC') {
        claim.email = req.body.email;
        claim.btcAddress = req.body.btcAddress;
        claim.ethAddress = req.body.ethAddress;
        claim.confirmation=0;
        claim.save(function (err, claim) {
          if (err) {
            response.code = ResponseCodeEnum.ERRORED;
            response.message = "Error for inserting Data to DB";
            response.data = err;
            res.json(response);
          }
          else {
            response.code = ResponseCodeEnum.SUCCESS;
            response.message = "User Created";
            response.data = claim;
            res.json(response);
          } //  end of else 
        });
      }
      else if (walletType == 'ETH') {
        claim.email = req.body.email;
        claim.ethAddress = req.body.ethAddress;
        claim.confirmation=0;
        claim.save(function (err, claim) {
          if (err) {
            response.code = ResponseCodeEnum.ERRORED;
            response.message = "Error for inserting Data to DB";
            response.data = err;
            res.json(response);
          }
          else {
            response.code = ResponseCodeEnum.SUCCESS;
            response.message = "User Created";
            response.data = claim;
            res.json(response);
          } //  end of else 
        });
      }
      else if (walletType == 'LTC') {
        claim.email = req.body.email;
        claim.ltcAddresss = req.body.ltcAddress;
        claim.ethAddress = req.body.ethAddress;
        claim.confirmation=0;
        claim.save(function (err, claim) {
          if (err) {
            response.code = ResponseCodeEnum.ERRORED;
            response.message = "Error for inserting Data to DB";
            response.data = err;
            res.json(response);
          }
          else {
            response.code = ResponseCodeEnum.SUCCESS;
            response.message = "User Created";
            response.data = claim;
            res.json(response);
          } //  end of else 
        });
      }
      else {
        response.code = ResponseCodeEnum.ERRORED;
        response.message = "Error for inserting Data to DB";
        response.data = err;
        res.json(response);
      }
    }
  });
});
postAddUser.post(function (req, res) {
  var user = new User();
  var response = new Response();
  User.findOne({ Email: req.body.Email }, function (err, existingUser) {
    if (existingUser != null) {
      response.code = ResponseCodeEnum.DECLINED;
      response.message = "User Already Exists";
      response.data = null;
      res.json(response);
    }
    else {
      user.Email = req.body.Email;
      user.Password = passwordHashing.createHash(req.body.Password);
      //***Wallet For New User */
      user.Role = 1;
      user.CreatedOnUTC = Math.floor(new Date());
      user.UpdatedOnUTC = Math.floor(new Date());
      user.save(function (err, user) {
        if (err) {
          response.code = ResponseCodeEnum.ERRORED;
          response.message = "Error for inserting Data to DB";
          response.data = err;
          res.json(response);
        }
        else {
          response.code = ResponseCodeEnum.SUCCESS;
          response.message = "User Created";
          user.Password = "";
          response.data = user;
          res.json(response);
        } //  end of else 
      });
    }
  });
});
postLoginUser.post(function (req, res) {
  var response = new Response();
  User.findOne({ Email: req.body.Email }, function (err, user) {
    if (user == null) {
      response.code = ResponseCodeEnum.DECLINED;
      response.message = "User Does not exists";
      response.data = null;
      res.json(response);
    }
    else {
      var validate = passwordHashing.validateHash(user.Password, req.body.Password);
      if (validate != true) {
        response.code = ResponseCodeEnum.DECLINED;
        response.message = "User Password is incorrect";
        response.data = null;
        return res.json(response);
      }
      response.code = ResponseCodeEnum.SUCCESS;
      response.message = "User Created";
      user.Password = "";
      response.data = user;
      res.json(response);
    }
  });
});
getDashboardData.get(function (req, res) {
  var response = new Response();
  var obj = new Object();
  var bitcoinurl = "https://chain.so/api/v2/get_address_balance/BTC/" + confFile.AdminBitcoinAddress;
  var litcoinurl = "https://chain.so/api/v2/get_address_balance/LTC/" + confFile.AdminLitcoinAddress;
  obj.ethers = tokenUtil.getBalance(confFile.AdminEthAddress);
  client.get(bitcoinurl, function (data, resp) {
    obj.bitcoins = data.data.confirmed_balance;
    obj.tokenRemaining = tokenUtil.balanceOf(confFile.AdminEthAddress);
    obj.totalCoins = tokenUtil.totalSupply();
    client.get(litcoinurl, function (data, resp) {
      obj.litcoins = data.data.confirmed_balance;
      response.code = 200;
      response.data = obj;
      response.message = "Success";
      res.json(response);
    });
  });

});

postAddUserWalletInfo.post(function (req, res) {
  var response = new Response();
  User.findOne({ EthAddress: req.body.EthAddress }, function (err, user) {
    if (user == null) {
      user = new User();
      user.EthAddress = req.body.EthAddress;
      user.EthAddress = user.EthAddress.toUpperCase();
      if (req.body.bitcoinAddress != null && req.body.bitcoinAddress != "") {
        user.WalletType = WalletTypeEnum.BITCOIN;
        user.WalletAddress = req.body.bitcoinAddress;
      }
      else if (req.body.ltcAddress != null && req.body.ltcAddress != "") {
        user.WalletType = WalletTypeEnum.LTC;
        user.WalletAddress = req.body.ltcAddress;
      }
      else {
        user.WalletType = WalletTypeEnum.ETHEREUM;
      }
      user.Email = req.body.Email;
      user.save(function (err, user) {
        response.code = ResponseCodeEnum.SUCCESS;
        response.message = "SUCCESS";
        response.data = user;
        res.json(response);
      });
    }
    else{
      response.code = ResponseCodeEnum.ERRORED;
      response.message = "FAILURE: User Already Exists";
      response.data = user;
      res.json(response);
    }
  });

});


module.exports = router;