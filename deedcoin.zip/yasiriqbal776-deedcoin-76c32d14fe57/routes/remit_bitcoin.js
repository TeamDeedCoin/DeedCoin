var express = require('express');
var router = express.Router();

var config = require('./../config');
var btc_address = config.AdminBitcoinAddress;//'1CjZ44n4a29YTr1GqQkNyzpH5ZGyiq4iby';//


var CryptoTypeEnum = require('./../enums/CryptoTypeEnum');
//Utiltiy Imported
var tokenUtil = require('./../utility/tokenUtil');
var tokenUtil = new tokenUtil();


var asyncLoop = require('node-async-loop');
var User = require('./../models/User');

// can be 'latest' or 'pending'

//var apiurl = "https://blockexplorer.com/";
var apiurl = "https://insight.bitpay.com/";
var socket = require('socket.io-client')(apiurl);


//For http requests handler
var Client = require('node-rest-client').Client;
var client = new Client();

socket.on('connect', function () {
  // Join the room.
  socket.emit('subscribe', 'inv');
});

socket.on('disconnect', function () {
  // Join the room.
  console.log("diconnect");
});

var transactionArray = [];
var bitcoin_work_flag = false;
socket.on('block', function (data) {
  console.log(data);
  if (transactionArray.length != 0 && bitcoin_work_flag == false) {
    processBlockOfBitcoin(transactionArray[0]);

  }//end of if
});

socket.on('tx', function (data) {
  //console.log(data);

  for (var i = 0; i < data.vout.length; i++) {
    var obj = data.vout[i];
    for (property in obj) {
      if (property === btc_address) {
        //    console.log(property);

        transactionArray.push(data);
        break;
      }
    }
  }
});

function processBitcoinBlockOutOfSocket() {
  if (transactionArray.length > 0 && bitcoin_work_flag == false) {
    processBlockOfBitcoin(transactionArray[0]);
  }
}

// var db = {
//   "txid": "649510aefc5881ea54892e7e40ea39b73a5a06c30affa489912efe37f80361a6",
//   "version": 2,
//   "locktime": 492099,
//   "vin": [
//     {
//       "txid": "09b2caf94877fc945f8548231b18d1b3d37971d5b2dd6859c5bacba4e93791ec",
//       "vout": 1,
//       "scriptSig": {
//         "asm": "3045022100be71a96bb31304e445b90488e474f3478467b41a05281f16880f9836099277d4022002d43474fcb63a432b6f6af50c1208475c08431b94b69c26776bae0fbf06e7ee[ALL] 02b439ee8d6ade9a20b6f8e9dafcd139cac940a4700b2a72df982a2008d0d4afb6",
//         "hex": "483045022100be71a96bb31304e445b90488e474f3478467b41a05281f16880f9836099277d4022002d43474fcb63a432b6f6af50c1208475c08431b94b69c26776bae0fbf06e7ee012102b439ee8d6ade9a20b6f8e9dafcd139cac940a4700b2a72df982a2008d0d4afb6"
//       },
//       "sequence": 4294967294,
//       "n": 0,
//       "addr": "1GSd5QWXs4u7T72LNhnyQjrmqse6UQx2Pa",
//       "valueSat": 499940000,
//       "value": 4.9994,
//       "doubleSpentTxID": null
//     }
//   ],
//   "vout": [
//     {
//       "value": "0.50000000",
//       "n": 0,
//       "scriptPubKey": {
//         "hex": "76a91480b59c423f1ced4f1001c97e3adc51c1be64bee788ac",
//         "asm": "OP_DUP OP_HASH160 80b59c423f1ced4f1001c97e3adc51c1be64bee7 OP_EQUALVERIFY OP_CHECKSIG",
//         "addresses": [
//           "1CjZ44n4a29YTr1GqQkNyzpH5ZGyiq4iby"
//         ],
//         "type": "pubkeyhash"
//       },
//       "spentTxId": "32e2e7b6a95c04943f30aeb596a1f1a96fc514c8f0c69aa17727688098ed0bac",
//       "spentIndex": 55,
//       "spentHeight": 492101
//     },
//     {
//       "value": "4.49714000",
//       "n": 1,
//       "scriptPubKey": {
//         "hex": "76a914e81d939be4b69a40e42d8ef385e8fd61938a785d88ac",
//         "asm": "OP_DUP OP_HASH160 e81d939be4b69a40e42d8ef385e8fd61938a785d OP_EQUALVERIFY OP_CHECKSIG",
//         "addresses": [
//           "1NAKCXKHnSXP2zrGx7dW7waLSPAXGeFswn"
//         ],
//         "type": "pubkeyhash"
//       },
//       "spentTxId": null,
//       "spentIndex": null,
//       "spentHeight": null
//     }
//   ],
//   "blockhash": "0000000000000000003c3f9042748ee9bf22c2caf8fc654e821266b70a0bce89",
//   "blockheight": 492100,
//   "confirmations": 11,
//   "time": 1509212969,
//   "blocktime": 1509212969,
//   "valueOut": 4.99714,
//   "size": 226,
//   "valueIn": 4.9994,
//   "fees": 0.00226
// };
// processBlockOfBitcoin(db);
function processBlockOfBitcoin(transactionObj) {
  bitcoin_work_flag = true;
  try {
    client.get('https://blockexplorer.com/api/tx/' + transactionObj.txid, function (data, resp) {
      if (data.confirmations > 0) {
        for (var i = 0; i < data.vout.length; i++) {
          var obj = data.vout[i].scriptPubKey.addresses;
          console.log(obj);
          for (var i = 0; i < obj.length; i++) {
            console.log(obj[i]);
            if (obj[i] === btc_address) {

              var amount = data.vout[i].value;
              console.log(amount);
              handleBitcoinIncoming(data,amount);
            }
          }
          bitcoin_work_flag = false;
          transactionArray.shift();
          processBitcoinBlockOutOfSocket();


        }
      }
      else {
        bitcoin_work_flag = false;
        transactionArray.shift();
        processBitcoinBlockOutOfSocket();
      }
    });
  }
  catch (ex) {
    bitcoin_work_flag = false;
    transactionArray.shift();
    processBitcoinBlockOutOfSocket();
    console.log(ex);
  }
}

function handleBitcoinIncoming(transactionObj,amount) {
  var arrAllInputs = [];
  for (var i = 0; i < transactionObj.vin.length; i++) {
      arrAllInputs.push(transactionObj.vin[i].addr);
  }//end of loop
  User.find({
    'WalletAddress': {
      $in:
      arrAllInputs
    }
  }, function (err, allUsers) {
    if (allUsers && allUsers.length > 0) {
      //Token Transfer for all users in async loop
      asyncLoop(allUsers, function (user, nextInner) {
        tokenUtil.transferTokensForUSD(user, amount, CryptoTypeEnum.BITCOIN, nextInner);
      }, function (err) {

        console.log('Finished!');
      });
    }
    else {
      next();
    }
    console.log(allUsers);
  });//end of userfindsd
}//end of function

module.exports = router;
