var cron = require('node-cron');
var config = require('./../config');


var LastLTCTransaction = require('./../models/LastLTCTransaction');
var CryptoTypeEnum = require('./../enums/CryptoTypeEnum');
//Utiltiy Imported
var tokenUtil = require('./../utility/tokenUtil');
var tokenUtil = new tokenUtil();


var asyncLoop = require('node-async-loop');
//Models Imported
var User = require('./../models/User');
//Mongo Connectivity with url in DBRUrl file
var mongoose = require('mongoose');
var DbUrl = require('./../utility/DbUrl');
var dbUrl = new DbUrl();
var url = dbUrl.getURL();
mongoose.connect(url, function (err, db) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("Successfully Connected in cron job");
    }
});
var urlGetInput = "https://chain.so/api/v2/get_tx_inputs/LTC/";
var urlGetRecieved = "https://chain.so/api/v2/get_tx_received/LTC/";
//For http requests handler
var Client = require('node-rest-client').Client;
var client = new Client();


var res = false;
cron.schedule('*/5 * * * *', function () {
    LastLTCTransaction.findOne({}, function (err, transObj) {
        if (err) {
            console.log(err);
        }//end of if
        else {
            var url = urlGetRecieved + config.AdminLitcoinAddress;
            if (transObj) {
               url = url + "/" + transObj.transactionHash;
            }//end of if ro transobj defined
            client.get(url, function (data, resp) {
                var allTrans = data.data.txs;
                if (allTrans && allTrans.length>0) {
                    handleAllLTCTrans(allTrans);
                }//end of allTransfrom server 
            });

        }
    }).sort({ CreatedOnUTC: 'desc', _id: -1 }).limit(1);//end of finding last transactions
});


function handleAllLTCTrans(allTrans) {

    asyncLoop(allTrans, function (transItem, next) {
        try {
            var url = urlGetInput + transItem.txid;
            setTimeout(function () {

                client.get(url, function (data, resp) {
                    if (data) {
                        if (Buffer.isBuffer(data)) {
                            data = data.toString('utf8');
                        }
                        var allInputs = data.data.inputs;
                        var arrAllInputs = [];
                        for (var i = 0; i < allInputs.length; i++) {
                            arrAllInputs.push(allInputs[i].address);
                        }//end of loop
                        User.find({
                            'WalletAddress': {
                                $in:
                                arrAllInputs
                            }
                        }, function (err, allUsers) {
                            if (allUsers && allUsers.length>0) {
                                //Token Transfer for all users in async loop
                                asyncLoop(allUsers, function (user, nextInner) {
                                    tokenUtil.transferTokensForUSD(user, transItem.value, CryptoTypeEnum.LITECOIN, nextInner);
                                }, function (err) {

                                   next();
                                    console.log('Finished!');
                                });
                            }
                            else{
                                next();
                            }
                            console.log(allUsers);
                        });
                    }//end of data
                    else {
                        next();
                    }
                });//handle resposne for getting inputs
            }, 3000);
        } catch (ex) {
            console.log(ex);
        }
    }, function (err) {
        if (err) {
            console.error('Error: ' + err.message);
            return;
        }
        
        if (allTrans.length >= 1) {
            var updatedTrasns = allTrans[(allTrans.length - 1)];
            var lastTrans = new LastLTCTransaction;
            lastTrans.transactionHash = updatedTrasns.txid;
            lastTrans.save();
        }
        console.log('Finished!');
    });

}//emnd offunciton


