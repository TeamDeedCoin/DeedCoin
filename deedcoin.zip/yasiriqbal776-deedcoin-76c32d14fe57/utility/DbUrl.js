var DbUrl = function Constructor() {

};


DbUrl.prototype.getURL = function () {
    // Connection URL. This is where your mongodb server is running.
    var url = 'mongodb://tauqeer:ideofuzion123@ds127105.mlab.com:27105/deedcoin';
    return url;
};

module.exports = DbUrl;