var Config = {
//Global Variables
AdminEthFundAddress : "0x9c609bfbd0e12ed9f8b1162a7c0f8fdf7fe48e68", //This will recieve balance 
AdminEthAddress : "0x9c609bfbd0e12ed9f8b1162a7c0f8fdf7fe48e68", //Test network distributor
AdminBitcoinAddress : "16rCmCmbuWDhPjWTrpQGaU3EPdZF7MTdUk", //Test network 
AdminLitcoinAddress : "LdP8Qox1VAhCzLJNqrr74YovaWYyNBUWvL", //Test netwokr 
AdminSmartContractAddress : "0x18F67A387d927AbD9c37C0CaeCD5CC9ba445DFfA", //deployed by above distributor address
AdminEthPassword : "Pakistan#12"  //password by users
};
module.exports = Config;